import React from 'react';
import { withStyles } from "@material-ui/core/styles";

const styles = theme => ({
  poster: {
    "margin-top": "10px"
  }
});

/**
 * Displays a 500 px wide movie poster
 * 
 * @param {string} path - path to poster image
 * 
 * @returns {ReactComponent} Poster 
 */
const Poster = ({classes, path, overview}) => { return (<h3>{overview}
  <img className={classes.poster} src={`https://image.tmdb.org/t/p/w500${path}`} alt=""/></h3>
)};
 
export default withStyles(styles)(Poster);