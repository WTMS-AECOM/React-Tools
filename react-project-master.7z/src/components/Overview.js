import React from 'react';


class Overview extends React.Component {
    constructor(overview) {
       super();
      }
      render() {
        return (<h2>{ this.overview }</h2>);
      }
}


export default Overview;