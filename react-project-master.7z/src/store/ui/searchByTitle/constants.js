export const SEARCH_BY_TITLE_SCOPE = "uiLayer/searchByTitle/title";
