import { RSAA } from "redux-api-middleware";
import { scopeTypeDescriptors } from "../../scope";
import { REQUEST, SUCCESS, FAILURE } from "../../loading";
import { COMPANY_RESULTS_SCOPE } from "./constants";

/**
 * Fetch a list of movies by title
 *
 * @param {string} title - title to query
 *
 * @return {object} RSAA request
 */
export const fetchCompanyByid = movieId => ({
  [RSAA]: {
    endpoint: `/movie/${movieId}`,
    method: "GET",
    types: scopeTypeDescriptors([REQUEST, SUCCESS, FAILURE], COMPANY_RESULTS_SCOPE),
    headers: { "Content-Type": "application/json" }
  }
});
