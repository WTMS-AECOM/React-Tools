import { createSelector } from "reselect";
import { createScopedSelector } from "../../scope";
import { getLoading, getData } from "../../loading";
import { COMPANY_RESULTS_SCOPE } from "./constants";

export const getCompanys = createScopedSelector(getData, COMPANY_RESULTS_SCOPE);

export const getCompanysIsLoading = createScopedSelector(
  getLoading,
  COMPANY_RESULTS_SCOPE
);

const getCompany = (state, movieId) => {
  const company = state.dataLayer.company.results.data.results;
  var company2 = [
    {
        production_companies: 
        {
              "id": (4616, 81667),
              "logo_path": (null, null),
              "name": ("Freestyle Releasing", "ShadowMachine"),
              "origin_country": ("", "US")
        }
      } 
    ];
  company.find(company => Number(company.id) === Number(movieId));
  company.concat(company2);
};

export const getCompanyById = createSelector(getCompany, company => company || []);
