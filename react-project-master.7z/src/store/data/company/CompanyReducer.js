import { combineReducers } from "redux";
import { createScopedReducer } from "../../scope";
import { LoadingReducer } from "../../loading";
import { COMPANY_RESULTS_SCOPE } from "./constants";

const CompanyReducer = combineReducers({
  results: createScopedReducer(LoadingReducer, COMPANY_RESULTS_SCOPE)
});

export default CompanyReducer;
