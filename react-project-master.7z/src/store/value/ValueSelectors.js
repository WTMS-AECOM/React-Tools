export const getValue = state => state;
